import React, { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Briefcase, Zap, Eye, EyeOff } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

export function Trading() {
  const [portfolioVisible, setPortfolioVisible] = useState(true);

  const investments = [
    { name: "Apple Inc.", symbol: "AAPL", price: 189.50, change: 2.3, changePercent: 1.23, holdings: 25 },
    { name: "Microsoft Corp.", symbol: "MSFT", price: 415.20, change: -1.8, changePercent: -0.43, holdings: 12 },
    { name: "Tesla Inc.", symbol: "TSLA", price: 248.90, change: 8.5, changePercent: 3.54, holdings: 8 },
    { name: "Amazon.com Inc.", symbol: "AMZN", price: 145.30, change: 0.9, changePercent: 0.62, holdings: 18 }
  ];

  const portfolioStats = {
    totalValue: 8245.60,
    dayGain: 412.30,
    totalGain: 1245.80,
    totalGainPercent: 17.8
  };

  const futureGoals = [
    {
      name: "Retirement Fund",
      target: 1000000,
      current: 320000,
      targetAge: 65,
      progress: 32
    },
    {
      name: "Children's College Fund",
      target: 200000,
      current: 36000,
      targetAge: null,
      progress: 18
    },
    {
      name: "Dream Home Down Payment",
      target: 100000,
      current: 45000,
      targetAge: null,
      progress: 45
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Investment Hub
              </CardTitle>
              <CardDescription>Automated trading & portfolio management</CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPortfolioVisible(!portfolioVisible)}
            >
              {portfolioVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Portfolio Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Portfolio Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Total Value</span>
              </div>
              <div className="text-2xl font-bold">
                {portfolioVisible ? `$${portfolioStats.totalValue.toLocaleString()}` : '••••••'}
              </div>
              <div className="text-sm text-green-600">+{portfolioStats.totalGainPercent}% all time</div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Day's Gain</span>
              </div>
              <div className="text-2xl font-bold">
                {portfolioVisible ? `+$${portfolioStats.dayGain.toLocaleString()}` : '••••••'}
              </div>
              <div className="text-sm text-muted-foreground">From auto-trading</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Automated Trading */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-green-600" />
              <CardTitle className="text-green-900">Automated Trading</CardTitle>
            </div>
            <Badge className="bg-green-600">Active</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-green-100/50 border border-green-200">
              <p className="text-sm text-green-700 mb-2">
                AI is actively managing your portfolio during market hours
              </p>
              <div className="text-xs text-green-600">
                Fee: 10% of profits • Next rebalance: 2:30 PM EST
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-green-700">Trading Status</span>
              <Button size="sm" variant="outline" className="border-green-300 text-green-700 hover:bg-green-100">
                Configure Settings
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Investment Holdings */}
      <Card>
        <CardHeader>
          <CardTitle>Your Holdings</CardTitle>
          <CardDescription>Current investment positions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {investments.map((stock, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-chart-1 rounded-lg flex items-center justify-center font-bold text-sm">
                    {stock.symbol.charAt(0)}
                  </div>
                  <div>
                    <div className="font-medium">{stock.symbol}</div>
                    <div className="text-sm text-muted-foreground">{stock.holdings} shares</div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-bold">${stock.price}</div>
                  <div className={`text-sm flex items-center justify-end ${
                    stock.change >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stock.change >= 0 ? 
                      <TrendingUp className="w-3 h-3 mr-1" /> : 
                      <TrendingDown className="w-3 h-3 mr-1" />
                    }
                    {stock.change >= 0 ? '+' : ''}{stock.changePercent}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Become an Entrepreneur Section */}
      <Card className="border-purple-200 bg-purple-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Briefcase className="h-5 w-5 text-purple-600" />
            <CardTitle className="text-purple-900">Become an Entrepreneur</CardTitle>
          </div>
          <CardDescription className="text-purple-700">
            Learn business fundamentals and start your entrepreneurial journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-purple-100/50 border border-purple-200">
              <h4 className="font-medium text-purple-900">Business Plan Workshop</h4>
              <p className="text-sm text-purple-700">Create your first business plan with AI guidance</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-100/50 border border-purple-200">
              <h4 className="font-medium text-purple-900">Market Research Tools</h4>
              <p className="text-sm text-purple-700">Analyze market opportunities and competition</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-100/50 border border-purple-200">
              <h4 className="font-medium text-purple-900">Funding Simulator</h4>
              <p className="text-sm text-purple-700">Practice pitching to virtual investors</p>
            </div>
          </div>
          
          <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
            Start Entrepreneur Journey
          </Button>
        </CardContent>
      </Card>

      {/* Future Goals */}
      <Card>
        <CardHeader>
          <CardTitle>Future Financial Goals</CardTitle>
          <CardDescription>Long-term investment targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {futureGoals.map((goal, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{goal.name}</div>
                    <div className="text-sm text-muted-foreground">
                      ${goal.current.toLocaleString()} of ${goal.target.toLocaleString()}
                      {goal.targetAge && ` • Target: Age ${goal.targetAge}`}
                    </div>
                  </div>
                  <Badge variant="outline">{goal.progress}% complete</Badge>
                </div>
                <Progress value={goal.progress} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Market Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Market Summary</CardTitle>
          <CardDescription>Today's market performance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-lg font-bold text-green-600">+1.2%</div>
              <div className="text-sm text-muted-foreground">S&P 500</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-lg font-bold text-green-600">+0.8%</div>
              <div className="text-sm text-muted-foreground">NASDAQ</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-lg font-bold text-red-600">-0.3%</div>
              <div className="text-sm text-muted-foreground">DOW</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/50">
              <div className="text-lg font-bold text-green-600">+2.1%</div>
              <div className="text-sm text-muted-foreground">Russell 2000</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}