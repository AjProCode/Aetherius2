import React, { useState, useEffect } from 'react';
import { DollarSign, Target, TrendingUp, AlertTriangle, Plus, Eye, EyeOff, RefreshCw } from 'lucide-react';
import { Progress } from './ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { createClient } from '../utils/supabase/client';
import { authenticatedRequest } from '../utils/api';

export function Dashboard({ userProfile }: { userProfile: any }) {
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  const [transactionForm, setTransactionForm] = useState({
    amount: '',
    description: '',
    category: 'other',
    type: 'expense'
  });
  const supabase = createClient();

  const fetchDashboardData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const [dashData, transData] = await Promise.all([
          authenticatedRequest(`/dashboard/${session.user.id}`, session.access_token),
          authenticatedRequest(`/transactions/${session.user.id}`, session.access_token)
        ]);
        setDashboardData(dashData);
        setTransactions(transData.slice(0, 5)); // Show latest 5 transactions
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchDashboardData();
  };

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await authenticatedRequest(
          `/transaction/${session.user.id}`,
          session.access_token,
          {
            method: 'POST',
            body: JSON.stringify({
              amount: parseFloat(transactionForm.amount),
              description: transactionForm.description,
              category: transactionForm.category,
              type: transactionForm.type
            }),
          }
        );

        // Reset form and refresh data
        setTransactionForm({ amount: '', description: '', category: 'other', type: 'expense' });
        setShowAddTransaction(false);
        fetchDashboardData();
      }
    } catch (error) {
      console.error('Failed to add transaction:', error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-muted rounded-lg animate-pulse"></div>
        <div className="h-48 bg-muted rounded-lg animate-pulse"></div>
        <div className="h-64 bg-muted rounded-lg animate-pulse"></div>
      </div>
    );
  }

  const budgetUsage = dashboardData?.budgetUsed && dashboardData?.monthlyBudget 
    ? (dashboardData.budgetUsed / dashboardData.monthlyBudget) * 100 
    : 0;

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">
                Welcome back, {userProfile?.name?.split(' ')[0] || 'User'}!
              </h2>
              <p className="text-muted-foreground">
                Here's your family's financial overview for today
              </p>
            </div>
            <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Balance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Balance</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setBalanceVisible(!balanceVisible)}
              className="h-6 w-6 p-0"
            >
              {balanceVisible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {balanceVisible ? `$${dashboardData?.totalBalance?.toLocaleString() || '0'}` : '••••••'}
            </div>
            <p className="text-xs text-muted-foreground">
              +2.1% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Monthly Income</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${dashboardData?.monthlyIncome?.toLocaleString() || '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              Set in your profile
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Budget Used</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {budgetUsage.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              ${dashboardData?.budgetUsed || 0} of ${dashboardData?.monthlyBudget || 0}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Budget Progress</CardTitle>
          <CardDescription>
            Track your spending against your monthly budget
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Spent this month</span>
              <span>${dashboardData?.budgetUsed?.toLocaleString() || 0} / ${dashboardData?.monthlyBudget?.toLocaleString() || 0}</span>
            </div>
            <Progress value={budgetUsage} className="h-3" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0%</span>
              <span className={budgetUsage > 80 ? 'text-destructive' : budgetUsage > 60 ? 'text-yellow-600' : 'text-green-600'}>
                {budgetUsage > 80 ? 'Over budget soon!' : budgetUsage > 60 ? 'Getting close' : 'On track'}
              </span>
              <span>100%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Savings Goals Progress */}
      {dashboardData?.savingsGoals?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Savings Goals</CardTitle>
            <CardDescription>Making progress towards your financial targets</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardData.savingsGoals.slice(0, 3).map((goal, index) => {
                const progress = (goal.current / goal.target) * 100;
                return (
                  <div key={goal.id} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{goal.title}</span>
                      <span className="text-sm text-muted-foreground">
                        ${goal.current.toLocaleString()} / ${goal.target.toLocaleString()}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <div className="text-xs text-muted-foreground">
                      {progress.toFixed(1)}% complete
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Manage your finances</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <Dialog open={showAddTransaction} onOpenChange={setShowAddTransaction}>
              <DialogTrigger asChild>
                <Button className="h-16 flex-col">
                  <Plus className="h-6 w-6 mb-1" />
                  Add Transaction
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Transaction</DialogTitle>
                  <DialogDescription>
                    Record a new income or expense
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddTransaction} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select value={transactionForm.type} onValueChange={(value) => setTransactionForm({ ...transactionForm, type: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="income">Income</SelectItem>
                          <SelectItem value="expense">Expense</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Amount ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={transactionForm.amount}
                        onChange={(e) => setTransactionForm({ ...transactionForm, amount: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      placeholder="What was this for?"
                      value={transactionForm.description}
                      onChange={(e) => setTransactionForm({ ...transactionForm, description: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={transactionForm.category} onValueChange={(value) => setTransactionForm({ ...transactionForm, category: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="groceries">Groceries</SelectItem>
                        <SelectItem value="entertainment">Entertainment</SelectItem>
                        <SelectItem value="transport">Transport</SelectItem>
                        <SelectItem value="utilities">Utilities</SelectItem>
                        <SelectItem value="salary">Salary</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={() => setShowAddTransaction(false)} className="flex-1">
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Add Transaction
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <Button variant="outline" className="h-16 flex-col">
              <TrendingUp className="h-6 w-6 mb-1" />
              View Investments
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Your latest financial activity</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length > 0 ? (
            <div className="space-y-3">
              {transactions.map((transaction, index) => (
                <div key={transaction.id || index} className="flex items-center justify-between p-3 rounded-lg border">
                  <div>
                    <div className="font-medium">{transaction.description}</div>
                    <div className="text-sm text-muted-foreground capitalize">
                      {transaction.category} • {new Date(transaction.date).toLocaleDateString()}
                    </div>
                  </div>
                  <div className={`font-medium ${transaction.type === 'income' ? 'text-green-600' : 'text-destructive'}`}>
                    {transaction.type === 'income' ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No transactions yet</p>
              <p className="text-sm">Add your first transaction to get started!</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Family Overview */}
      {dashboardData?.children?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Family Overview</CardTitle>
            <CardDescription>Your children's financial progress</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dashboardData.children.map((child, index) => (
                <div key={child.id || index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-chart-4 rounded-full flex items-center justify-center text-primary-foreground font-bold">
                      {child.name?.[0]?.toUpperCase() || 'C'}
                    </div>
                    <div>
                      <div className="font-medium">{child.name} (Age {child.age})</div>
                      <div className="text-sm text-muted-foreground">Balance: ${child.balance || 0}</div>
                    </div>
                  </div>
                  <Badge variant="secondary">
                    {child.points || 0} points
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}