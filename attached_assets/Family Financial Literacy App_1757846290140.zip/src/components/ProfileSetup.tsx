import React, { useState } from 'react';
import { ArrowRight, Plus, Trash2, User, Users, DollarSign } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { createClient } from '../utils/supabase/client';
import { authenticatedRequest } from '../utils/api';

export function ProfileSetup({ onComplete, user }: { onComplete: (profile: any) => void; user: any }) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    familyName: '',
    monthlyIncome: '',
    monthlyBudget: '',
    financialGoals: [],
    children: []
  });
  const supabase = createClient();

  const addChild = () => {
    setFormData({
      ...formData,
      children: [...formData.children, { name: '', age: '', allowance: '' }]
    });
  };

  const removeChild = (index: number) => {
    const newChildren = formData.children.filter((_, i) => i !== index);
    setFormData({ ...formData, children: newChildren });
  };

  const updateChild = (index: number, field: string, value: string) => {
    const newChildren = [...formData.children];
    newChildren[index] = { ...newChildren[index], [field]: value };
    setFormData({ ...formData, children: newChildren });
  };

  const addFinancialGoal = (goal: string) => {
    if (!formData.financialGoals.includes(goal)) {
      setFormData({
        ...formData,
        financialGoals: [...formData.financialGoals, goal]
      });
    }
  };

  const removeFinancialGoal = (goal: string) => {
    setFormData({
      ...formData,
      financialGoals: formData.financialGoals.filter(g => g !== goal)
    });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const profile = await authenticatedRequest(
          `/profile/${session.user.id}`,
          session.access_token,
          {
            method: 'POST',
            body: JSON.stringify({
              ...formData,
              setupComplete: true,
              monthlyIncome: parseFloat(formData.monthlyIncome) || 0,
              monthlyBudget: parseFloat(formData.monthlyBudget) || 0,
              children: formData.children.map(child => ({
                ...child,
                age: parseInt(child.age) || 0,
                allowance: parseFloat(child.allowance) || 0,
                balance: 0,
                points: 0
              }))
            }),
          }
        );
        onComplete(profile);
      }
    } catch (error) {
      console.error('Profile setup error:', error);
    } finally {
      setLoading(false);
    }
  };

  const goalOptions = [
    'Emergency Fund',
    'House Down Payment',
    'Retirement Savings',
    'Children\'s Education',
    'Family Vacation',
    'New Car',
    'Debt Payoff',
    'Investment Growth'
  ];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <Card>
          <CardHeader className="text-center">
            <CardTitle>Let's Set Up Your Profile</CardTitle>
            <CardDescription>
              Help us personalize your Aetherius experience
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {step === 1 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Basic Information
                </h3>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Your Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="familyName">Family Name (Optional)</Label>
                    <Input
                      id="familyName"
                      placeholder="e.g., The Smith Family"
                      value={formData.familyName}
                      onChange={(e) => setFormData({ ...formData, familyName: e.target.value })}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="income">Monthly Income ($)</Label>
                      <Input
                        id="income"
                        type="number"
                        placeholder="5000"
                        value={formData.monthlyIncome}
                        onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="budget">Monthly Budget ($)</Label>
                      <Input
                        id="budget"
                        type="number"
                        placeholder="4000"
                        value={formData.monthlyBudget}
                        onChange={(e) => setFormData({ ...formData, monthlyBudget: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                
                <Button onClick={() => setStep(2)} className="w-full">
                  Next: Financial Goals
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Financial Goals
                </h3>
                
                <p className="text-sm text-muted-foreground">
                  Select your main financial priorities (choose as many as apply):
                </p>
                
                <div className="grid grid-cols-2 gap-3">
                  {goalOptions.map((goal) => (
                    <Button
                      key={goal}
                      variant={formData.financialGoals.includes(goal) ? "default" : "outline"}
                      className="h-auto p-4 text-left justify-start"
                      onClick={() => 
                        formData.financialGoals.includes(goal) 
                          ? removeFinancialGoal(goal)
                          : addFinancialGoal(goal)
                      }
                    >
                      {goal}
                    </Button>
                  ))}
                </div>
                
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Previous
                  </Button>
                  <Button onClick={() => setStep(3)} className="flex-1">
                    Next: Family Members
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-medium flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Family Members
                </h3>
                
                <p className="text-sm text-muted-foreground">
                  Add your children to get started with family financial education:
                </p>
                
                <div className="space-y-4">
                  {formData.children.map((child, index) => (
                    <Card key={index} className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="flex-1 grid grid-cols-3 gap-3">
                          <div className="space-y-1">
                            <Label className="text-xs">Name</Label>
                            <Input
                              placeholder="Child's name"
                              value={child.name}
                              onChange={(e) => updateChild(index, 'name', e.target.value)}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">Age</Label>
                            <Input
                              type="number"
                              placeholder="Age"
                              value={child.age}
                              onChange={(e) => updateChild(index, 'age', e.target.value)}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">Weekly Allowance ($)</Label>
                            <Input
                              type="number"
                              placeholder="10"
                              value={child.allowance}
                              onChange={(e) => updateChild(index, 'allowance', e.target.value)}
                            />
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeChild(index)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                  
                  <Button variant="outline" onClick={addChild} className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Child
                  </Button>
                </div>
                
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
                    Previous
                  </Button>
                  <Button onClick={handleSubmit} disabled={loading} className="flex-1">
                    {loading ? 'Setting Up...' : 'Complete Setup'}
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}