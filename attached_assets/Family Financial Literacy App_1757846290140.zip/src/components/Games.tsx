import React from 'react';
import { Gamepad2, Play, Star, Clock, Users, Trophy, Gift } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function Games() {
  const games = [
    {
      id: 1,
      title: "Money Mountain",
      description: "Climb the mountain by making smart spending decisions!",
      category: "Smart Spending",
      difficulty: "Easy",
      duration: "5 min",
      players: "1-4",
      rating: 4.8,
      image: "🏔️",
      bgColor: "bg-blue-50 border-blue-200"
    },
    {
      id: 2,
      title: "Compound Castle",
      description: "Build your castle with the power of compound interest!",
      category: "Investment",
      difficulty: "Medium",
      duration: "10 min", 
      players: "2-6",
      rating: 4.9,
      image: "🏰",
      bgColor: "bg-purple-50 border-purple-200"
    },
    {
      id: 3,
      title: "Budget Battle",
      description: "Compete with family members to create the best budget!",
      category: "Budgeting",
      difficulty: "Hard",
      duration: "15 min",
      players: "2-8",
      rating: 4.7,
      image: "⚔️",
      bgColor: "bg-orange-50 border-orange-200"
    }
  ];

  const videos = [
    {
      id: 1,
      title: "What is Compound Interest?",
      duration: "3:45",
      views: "1.2K",
      thumbnail: "📈",
      category: "Investment Basics"
    },
    {
      id: 2,
      title: "Smart Shopping Tips",
      duration: "2:30",
      views: "856",
      thumbnail: "🛒",
      category: "Budgeting"
    },
    {
      id: 3,
      title: "Building Your First Budget",
      duration: "5:12",
      views: "2.1K",
      thumbnail: "💰",
      category: "Financial Planning"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="h-5 w-5" />
                Finance Games
              </CardTitle>
              <CardDescription>Learn while you play!</CardDescription>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold">Level 5</div>
              <div className="text-xs text-muted-foreground">Finance Explorer</div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Featured Games */}
      <div className="space-y-4">
        {games.map((game) => (
          <Card key={game.id} className={game.bgColor}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-4xl">{game.image}</div>
                  <div>
                    <CardTitle className="text-lg">{game.title}</CardTitle>
                    <CardDescription className="mt-1">{game.description}</CardDescription>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        <span className="text-sm font-medium">{game.rating}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {game.category}
                      </Badge>
                    </div>
                  </div>
                </div>
                <Button size="sm" className="shrink-0">
                  <Play className="h-4 w-4 mr-1" />
                  Play
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <div className="flex items-center gap-4">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{game.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    <span>{game.players} players</span>
                  </div>
                </div>
                <Badge variant="outline">
                  {game.difficulty}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Educational Videos */}
      <Card>
        <CardHeader>
          <CardTitle>Learn Videos</CardTitle>
          <CardDescription>Short educational content</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {videos.map((video) => (
              <div key={video.id} className="flex items-center gap-3 p-3 rounded-lg border">
                <div className="text-2xl">{video.thumbnail}</div>
                <div className="flex-1">
                  <h4 className="font-medium">{video.title}</h4>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{video.duration}</span>
                    <span>•</span>
                    <span>{video.views} views</span>
                    <span>•</span>
                    <Badge variant="outline" className="text-xs">{video.category}</Badge>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <Play className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Daily Challenge */}
      <Card className="border-yellow-200 bg-yellow-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <div className="text-3xl">🎯</div>
            <div>
              <CardTitle className="text-yellow-900">Daily Challenge</CardTitle>
              <CardDescription className="text-yellow-700">Complete for bonus points!</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <p className="text-sm text-yellow-700">
              "Save $5 today by cooking dinner at home instead of ordering takeout"
            </p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Gift className="h-4 w-4 text-yellow-600" />
                <span className="text-sm font-medium text-yellow-900">Reward: 50 points</span>
              </div>
              <Button size="sm" variant="outline" className="border-yellow-300 text-yellow-700 hover:bg-yellow-100">
                Accept Challenge
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Recent Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <div className="text-2xl">🏆</div>
              <div>
                <h4 className="font-medium">Budget Master</h4>
                <p className="text-sm text-muted-foreground">Completed 5 budgeting games</p>
              </div>
              <Badge variant="secondary">New!</Badge>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <div className="text-2xl">⭐</div>
              <div>
                <h4 className="font-medium">Smart Spender</h4>
                <p className="text-sm text-muted-foreground">Made 10 smart spending choices</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <div className="text-2xl">🎮</div>
              <div>
                <h4 className="font-medium">Game Explorer</h4>
                <p className="text-sm text-muted-foreground">Played all game categories</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-chart-1">24</div>
              <div className="text-sm text-muted-foreground">Games Completed</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-chart-2">1,250</div>
              <div className="text-sm text-muted-foreground">Points Earned</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-chart-3">12</div>
              <div className="text-sm text-muted-foreground">Videos Watched</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-muted/50">
              <div className="text-2xl font-bold text-chart-4">8</div>
              <div className="text-sm text-muted-foreground">Achievements</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}