import React from 'react';
import { Shield, AlertTriangle, Eye, CreditCard, FileText, Clock, CheckCircle } from 'lucide-react';
import { Progress } from './ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';

export function Protection() {
  const alerts = [
    {
      id: 1,
      type: "scam",
      title: "Suspicious Email Detected",
      message: "Phishing email claiming to be from your bank was blocked",
      time: "2 hours ago",
      severity: "high"
    },
    {
      id: 2,
      type: "spending",
      title: "Unusual Spending Pattern",
      message: "Large withdrawal of $800 detected at ATM",
      time: "5 hours ago",
      severity: "medium"
    }
  ];

  const insurancePolicies = [
    {
      name: "Health Insurance",
      provider: "BlueCross",
      premium: "$420/month",
      coverage: "$2M",
      expires: "Dec 2024",
      status: "active"
    },
    {
      name: "Life Insurance",
      provider: "MetLife", 
      premium: "$89/month",
      coverage: "$500K",
      expires: "Mar 2025",
      status: "active"
    },
    {
      name: "Auto Insurance",
      provider: "GEICO",
      premium: "$156/month", 
      coverage: "$100K",
      expires: "Sep 2024",
      status: "expiring_soon"
    }
  ];

  const loans = [
    {
      name: "Home Mortgage",
      balance: "$245,600",
      payment: "$1,850/month",
      rate: "3.25%",
      remaining: "22 years",
      progress: 25
    },
    {
      name: "Car Loan", 
      balance: "$18,400",
      payment: "$420/month",
      rate: "4.5%",
      remaining: "3.2 years",
      progress: 75
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Protection Center
              </CardTitle>
              <CardDescription>Security, insurance & loans</CardDescription>
            </div>
            <Badge className="bg-green-600">All Systems Protected</Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Security Status */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-green-600" />
              <CardTitle className="text-green-900">Security Status</CardTitle>
            </div>
            <Badge className="bg-green-600">Protected</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 rounded-lg bg-green-100/50 border border-green-200">
              <div className="text-2xl font-bold text-green-700">47</div>
              <div className="text-sm text-green-600">Scams Blocked</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-green-100/50 border border-green-200">
              <div className="text-2xl font-bold text-green-700">12</div>
              <div className="text-sm text-green-600">Alerts Sent</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Alerts */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            <CardTitle>Recent Alerts</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <Alert key={alert.id} variant={alert.severity === 'high' ? 'destructive' : 'default'}>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-medium">{alert.title}</div>
                      <div className="text-sm">{alert.message}</div>
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {alert.time}
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Insurance Policies */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <CardTitle>Insurance Policies</CardTitle>
          </div>
          <CardDescription>Manage your coverage and premiums</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {insurancePolicies.map((policy, index) => (
              <div key={index} className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{policy.name}</h4>
                  <div className="flex items-center gap-2">
                    <Badge 
                      variant={policy.status === 'active' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {policy.status === 'active' ? 'Active' : 'Expiring Soon'}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{policy.provider}</span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">Premium</div>
                    <div className="font-medium">{policy.premium}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Coverage</div>
                    <div className="font-medium">{policy.coverage}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Expires</div>
                    <div className="font-medium">{policy.expires}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Loans & EMI */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            <CardTitle>Loans & EMI</CardTitle>
          </div>
          <CardDescription>Track your loan payments and balances</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {loans.map((loan, index) => (
              <div key={index} className="p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{loan.name}</h4>
                  <div className="font-bold">{loan.balance}</div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                  <div>
                    <div className="text-muted-foreground">Monthly Payment</div>
                    <div className="font-medium">{loan.payment}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Interest Rate</div>
                    <div className="font-medium">{loan.rate}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Remaining</div>
                    <div className="font-medium">{loan.remaining}</div>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Paid off</span>
                    <span>{loan.progress}%</span>
                  </div>
                  <Progress value={loan.progress} className="h-2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Real-time Financial Statement */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-blue-900">Real-time Financial Statement</CardTitle>
          </div>
          <CardDescription className="text-blue-700">
            Updated every transaction
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-blue-100/50 border border-blue-200">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-blue-600">Total Assets</div>
                  <div className="text-xl font-bold text-blue-900">$287,450</div>
                </div>
                <div>
                  <div className="text-sm text-blue-600">Total Liabilities</div>
                  <div className="text-xl font-bold text-blue-900">$264,000</div>
                </div>
              </div>
              
              <div className="border-t border-blue-200 pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-blue-700">Net Worth</span>
                  <span className="text-2xl font-bold text-green-600">$23,450</span>
                </div>
              </div>
            </div>
            
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Download Full Statement
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security Features */}
      <Card>
        <CardHeader>
          <CardTitle>Security Features</CardTitle>
          <CardDescription>Your financial protection tools</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-lg border">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <div className="font-medium">Real-time Fraud Monitoring</div>
                <div className="text-sm text-muted-foreground">24/7 transaction monitoring</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg border">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <div className="font-medium">Scam Email Protection</div>
                <div className="text-sm text-muted-foreground">AI-powered phishing detection</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg border">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <div className="font-medium">Unusual Activity Alerts</div>
                <div className="text-sm text-muted-foreground">Instant notifications for suspicious transactions</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-lg border">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <div className="font-medium">Encrypted Data Storage</div>
                <div className="text-sm text-muted-foreground">Bank-level security for your information</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}