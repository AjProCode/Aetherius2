import React, { useState } from 'react';
import { Baby, Play, PiggyBank, Star, Gift, Trophy, ArrowLeft, BookOpen } from 'lucide-react';
import { Progress } from './ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function FootstepsSection() {
  const [showFootsteps, setShowFootsteps] = useState(false);
  const [activeChild, setActiveChild] = useState(null);

  const children = [
    {
      id: 1,
      name: "Emma",
      age: 12,
      balance: 125.50,
      points: 450,
      level: "Silver Saver",
      avatar: "🧒",
      bgColor: "bg-chart-4"
    },
    {
      id: 2,
      name: "Lucas",
      age: 9,
      balance: 87.25,
      points: 320,
      level: "Bronze Explorer",
      avatar: "👦",
      bgColor: "bg-chart-5"
    }
  ];

  const kidGames = [
    {
      title: "Coin Collector",
      description: "Catch falling coins and learn their values!",
      icon: "🪙",
      difficulty: "Easy",
      points: 25,
      category: "Learning"
    },
    {
      title: "Shop Smart",
      description: "Help mom buy groceries within budget",
      icon: "🛒",
      difficulty: "Medium",
      points: 50,
      category: "Budgeting"
    },
    {
      title: "Piggy Bank Race",
      description: "Race to fill your piggy bank fastest!",
      icon: "🐷",
      difficulty: "Easy",
      points: 30,
      category: "Saving"
    }
  ];

  const videos = [
    { title: "Why Do We Need Money?", duration: "2:15", icon: "💰", category: "Basics" },
    { title: "Saving vs Spending", duration: "3:20", icon: "🏦", category: "Concepts" },
    { title: "What is Interest?", duration: "2:45", icon: "📈", category: "Advanced" }
  ];

  if (!showFootsteps) {
    return (
      <div className="px-6 mb-6">
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Baby className="h-8 w-8 text-yellow-600" />
                <div>
                  <h3 className="font-bold text-yellow-900">Footsteps</h3>
                  <p className="text-yellow-700">Kids' Financial Learning</p>
                </div>
              </div>
              <Button 
                onClick={() => setShowFootsteps(true)}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                Open Footsteps
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-4">
              {children.map((child) => (
                <div key={child.id} className="p-3 rounded-lg bg-yellow-100/50 border border-yellow-200">
                  <div className="text-center">
                    <div className="text-2xl mb-2">{child.avatar}</div>
                    <div className="font-medium text-yellow-900">{child.name}</div>
                    <div className="text-sm text-yellow-700">${child.balance}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeChild) {
    const child = children.find(c => c.id === activeChild);
    
    return (
      <div className="fixed inset-0 bg-background z-50 overflow-y-auto">
        <div className="min-h-screen pb-20">
          {/* Header */}
          <div className="bg-card border-b border-border">
            <div className="px-6 py-4">
              <div className="flex items-center justify-between">
                <Button 
                  variant="outline"
                  onClick={() => setActiveChild(null)}
                  size="sm"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <div className="text-center">
                  <div className="text-3xl mb-1">{child.avatar}</div>
                  <h2 className="font-bold">{child.name}'s Account</h2>
                  <p className="text-sm text-muted-foreground">{child.level}</p>
                </div>
                <div className="w-16" />
              </div>
            </div>
          </div>

          <div className="px-6 py-6 space-y-6">
            {/* Balance & Points */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <PiggyBank className="h-6 w-6 mx-auto mb-2 text-chart-1" />
                  <div className="text-xl font-bold">${child.balance}</div>
                  <div className="text-sm text-muted-foreground">Savings Balance</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Star className="h-6 w-6 mx-auto mb-2 text-yellow-500" />
                  <div className="text-xl font-bold">{child.points}</div>
                  <div className="text-sm text-muted-foreground">Reward Points</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                        <Gift className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">Allowance received</div>
                        <div className="text-xs text-muted-foreground">Yesterday</div>
                      </div>
                    </div>
                    <Badge className="bg-green-600">+$10</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-chart-2 rounded-full flex items-center justify-center">
                        <Star className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-medium">Completed game</div>
                        <div className="text-xs text-muted-foreground">2 days ago</div>
                      </div>
                    </div>
                    <Badge variant="outline">+25 pts</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Learn Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Learn
                </CardTitle>
                <CardDescription>Fun finance videos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {videos.map((video, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg border">
                      <div className="text-2xl">{video.icon}</div>
                      <div className="flex-1">
                        <div className="font-medium">{video.title}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-2">
                          <span>{video.duration}</span>
                          <Badge variant="outline" className="text-xs">{video.category}</Badge>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Games Section */}
            <Card>
              <CardHeader>
                <CardTitle>Play & Learn</CardTitle>
                <CardDescription>Interactive financial games</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {kidGames.map((game, index) => (
                    <div key={index} className="p-3 rounded-lg border">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">{game.icon}</div>
                          <div>
                            <h4 className="font-medium">{game.title}</h4>
                            <p className="text-sm text-muted-foreground">{game.description}</p>
                          </div>
                        </div>
                        <Button size="sm">
                          <Play className="h-4 w-4 mr-1" />
                          Play
                        </Button>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">{game.category}</Badge>
                          <Badge variant="outline" className="text-xs">{game.difficulty}</Badge>
                        </div>
                        <span className="text-yellow-600 font-medium">+{game.points} points</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Savings Goals */}
            <Card>
              <CardHeader>
                <CardTitle>Savings Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">New Video Game</span>
                      <span className="text-muted-foreground">$60</span>
                    </div>
                    <Progress value={75} className="h-2" />
                    <div className="text-sm text-muted-foreground">$45 of $60 saved</div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Art Supplies</span>
                      <span className="text-muted-foreground">$25</span>
                    </div>
                    <Progress value={40} className="h-2" />
                    <div className="text-sm text-muted-foreground">$10 of $25 saved</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-background z-50 overflow-y-auto">
      <div className="min-h-screen pb-20">
        {/* Header */}
        <div className="bg-card border-b border-border">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <Button 
                variant="outline"
                onClick={() => setShowFootsteps(false)}
                size="sm"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div className="text-center">
                <h1 className="font-bold">Footsteps</h1>
                <p className="text-sm text-muted-foreground">Kids' Financial Adventure</p>
              </div>
              <div className="w-16" />
            </div>
          </div>
        </div>

        {/* Children Accounts */}
        <div className="px-6 py-6">
          <div className="space-y-4">
            {children.map((child) => (
              <Card 
                key={child.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setActiveChild(child.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-5xl">{child.avatar}</div>
                      <div>
                        <h3 className="font-bold text-lg">{child.name}</h3>
                        <p className="text-muted-foreground">Age {child.age} • {child.level}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <PiggyBank className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">${child.balance}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center gap-1 mb-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="font-bold">{child.points}</span>
                      </div>
                      <Badge variant="outline">Tap to Enter</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Family Challenge */}
          <Card className="mt-6 border-purple-200 bg-purple-50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-purple-600" />
                <CardTitle className="text-purple-900">Family Challenge</CardTitle>
              </div>
              <CardDescription className="text-purple-700">
                This week's challenge: Save $5 each by finding creative ways to spend less!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {children.map((child) => (
                  <div key={child.id} className="text-center p-4 rounded-lg bg-purple-100/50 border border-purple-200">
                    <div className="text-2xl mb-2">{child.avatar}</div>
                    <div className="font-medium text-purple-900">{child.name}</div>
                    <div className="text-sm text-green-600">$3.50 saved</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}