import React, { useState } from 'react';
import { ArrowRight, PiggyBank, Users, TrendingUp, Shield, Target, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';

export function OnboardingFlow({ onComplete }: { onComplete: () => void }) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: "Welcome to Aetherius!",
      subtitle: "Your Family's Financial Future Starts Here",
      description: "Aetherius helps families learn about money, save together, and build wealth through fun, interactive experiences.",
      icon: PiggyBank,
      color: "text-chart-1",
      features: [
        "Track family finances in real-time",
        "Set and achieve savings goals together",
        "Learn through interactive games",
        "Smart investment guidance"
      ]
    },
    {
      title: "Bring Your Family Together",
      subtitle: "Financial Education for Everyone",
      description: "Create accounts for your children and teach them money management through age-appropriate games and challenges.",
      icon: Users,
      color: "text-chart-2",
      features: [
        "Dedicated kids' section 'Footsteps'",
        "Age-appropriate financial games",
        "Family savings competitions",
        "Real-time allowance tracking"
      ]
    },
    {
      title: "Smart Investing Made Simple",
      subtitle: "Grow Your Wealth Automatically",
      description: "Let our AI-powered investment tools help you build long-term wealth with automated trading and portfolio management.",
      icon: TrendingUp,
      color: "text-chart-3",
      features: [
        "Automated investment strategies",
        "Real-time portfolio tracking",
        "Entrepreneur education center",
        "Future goal planning"
      ]
    },
    {
      title: "Complete Financial Protection",
      subtitle: "Security & Peace of Mind",
      description: "Advanced scam detection, insurance management, and loan tracking keep your family's finances secure.",
      icon: Shield,
      color: "text-chart-4",
      features: [
        "AI-powered scam detection",
        "Insurance policy management",
        "Loan and EMI tracking",
        "Real-time financial statements"
      ]
    },
    {
      title: "Ready to Transform Your Finances?",
      subtitle: "Let's Set Up Your Family Profile",
      description: "In the next step, we'll gather some basic information to personalize your Aetherius experience.",
      icon: Target,
      color: "text-chart-5",
      features: [
        "5-minute setup process",
        "Secure data encryption",
        "Personalized recommendations",
        "Start with any budget size"
      ]
    }
  ];

  const currentStepData = steps[currentStep];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <Card className="overflow-hidden">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className={`p-4 rounded-full bg-muted ${currentStepData.color}`}>
                <currentStepData.icon className="h-12 w-12" />
              </div>
            </div>
            <CardTitle className="text-2xl">{currentStepData.title}</CardTitle>
            <CardDescription className="text-lg">{currentStepData.subtitle}</CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <p className="text-center text-muted-foreground">
              {currentStepData.description}
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {currentStepData.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>

            {/* Progress Indicator */}
            <div className="space-y-2">
              <div className="flex justify-center space-x-2">
                {steps.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentStep ? 'bg-primary' : 
                      index < currentStep ? 'bg-primary/50' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
              <p className="text-center text-sm text-muted-foreground">
                Step {currentStep + 1} of {steps.length}
              </p>
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between gap-4">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
                className="flex-1"
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>
              
              {currentStep === steps.length - 1 ? (
                <Button onClick={onComplete} className="flex-1">
                  Get Started
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
                  className="flex-1"
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>

            {/* Skip Option */}
            {currentStep < steps.length - 1 && (
              <div className="text-center">
                <Button variant="ghost" onClick={onComplete} className="text-sm">
                  Skip Introduction
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}