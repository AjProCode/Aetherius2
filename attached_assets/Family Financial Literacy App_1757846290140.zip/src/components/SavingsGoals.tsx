import React, { useState, useEffect } from 'react';
import { Target, Trophy, Plus, DollarSign, Calendar, Edit, Trash2 } from 'lucide-react';
import { Progress } from './ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { createClient } from '../utils/supabase/client';
import { authenticatedRequest } from '../utils/api';

export function SavingsGoals({ userProfile }: { userProfile: any }) {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddGoal, setShowAddGoal] = useState(false);
  const [showAddMoney, setShowAddMoney] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [goalForm, setGoalForm] = useState({
    title: '',
    target: '',
    category: 'personal',
    deadline: ''
  });
  const [depositAmount, setDepositAmount] = useState('');
  const supabase = createClient();

  const fetchGoals = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const dashboardData = await authenticatedRequest(
          `/dashboard/${session.user.id}`,
          session.access_token
        );
        setGoals(dashboardData.savingsGoals || []);
      }
    } catch (error) {
      console.error('Failed to fetch goals:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoals();
  }, []);

  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await authenticatedRequest(
          `/savings-goal/${session.user.id}`,
          session.access_token,
          {
            method: 'POST',
            body: JSON.stringify({
              title: goalForm.title,
              target: parseFloat(goalForm.target),
              category: goalForm.category,
              deadline: goalForm.deadline,
              current: 0
            }),
          }
        );

        setGoalForm({ title: '', target: '', category: 'personal', deadline: '' });
        setShowAddGoal(false);
        fetchGoals();
      }
    } catch (error) {
      console.error('Failed to create goal:', error);
    }
  };

  const handleAddMoney = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user && selectedGoal) {
        await authenticatedRequest(
          `/savings-goal/${session.user.id}/${selectedGoal.id}`,
          session.access_token,
          {
            method: 'PUT',
            body: JSON.stringify({
              amount: parseFloat(depositAmount)
            }),
          }
        );

        setDepositAmount('');
        setShowAddMoney(false);
        setSelectedGoal(null);
        fetchGoals();
      }
    } catch (error) {
      console.error('Failed to add money:', error);
    }
  };

  const handleDeleteGoal = async (goalId: number) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await authenticatedRequest(
          `/savings-goal/${session.user.id}/${goalId}`,
          session.access_token,
          {
            method: 'DELETE',
          }
        );
        fetchGoals();
      }
    } catch (error) {
      console.error('Failed to delete goal:', error);
    }
  };

  const openAddMoney = (goal) => {
    setSelectedGoal(goal);
    setShowAddMoney(true);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-muted rounded-lg animate-pulse"></div>
        <div className="h-48 bg-muted rounded-lg animate-pulse"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Savings Goals
              </CardTitle>
              <CardDescription>Track and achieve your financial targets</CardDescription>
            </div>
            <Dialog open={showAddGoal} onOpenChange={setShowAddGoal}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Goal
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Savings Goal</DialogTitle>
                  <DialogDescription>
                    Set a new financial target to work towards
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreateGoal} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Goal Title</Label>
                    <Input
                      placeholder="e.g., Emergency Fund, New Car"
                      value={goalForm.title}
                      onChange={(e) => setGoalForm({ ...goalForm, title: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Target Amount ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="5000"
                        value={goalForm.target}
                        onChange={(e) => setGoalForm({ ...goalForm, target: e.target.value })}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select value={goalForm.category} onValueChange={(value) => setGoalForm({ ...goalForm, category: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="emergency">Emergency Fund</SelectItem>
                          <SelectItem value="vacation">Vacation</SelectItem>
                          <SelectItem value="home">Home Purchase</SelectItem>
                          <SelectItem value="car">Vehicle</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="personal">Personal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Target Date (Optional)</Label>
                    <Input
                      type="date"
                      value={goalForm.deadline}
                      onChange={(e) => setGoalForm({ ...goalForm, deadline: e.target.value })}
                    />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={() => setShowAddGoal(false)} className="flex-1">
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Create Goal
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Goals Overview */}
      {goals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Goals Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-chart-1">{goals.length}</div>
                <div className="text-sm text-muted-foreground">Active Goals</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-chart-2">
                  ${goals.reduce((sum, goal) => sum + (goal.current || 0), 0).toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Total Saved</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-chart-3">
                  ${goals.reduce((sum, goal) => sum + (goal.target || 0), 0).toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">Total Target</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Active Goals */}
      {goals.length > 0 ? (
        <div className="space-y-4">
          {goals.map((goal) => {
            const percentage = goal.target ? (goal.current / goal.target) * 100 : 0;
            const remaining = goal.target - goal.current;
            
            return (
              <Card key={goal.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{goal.title}</CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="capitalize">{goal.category}</Badge>
                        {goal.deadline && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Calendar className="h-3 w-3 mr-1" />
                            {new Date(goal.deadline).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">${goal.current?.toLocaleString() || 0}</div>
                      <div className="text-sm text-muted-foreground">of ${goal.target?.toLocaleString() || 0}</div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{percentage.toFixed(1)}% complete</span>
                        <span>${remaining.toLocaleString()} remaining</span>
                      </div>
                      <Progress value={percentage} className="h-3" />
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => openAddMoney(goal)}
                        className="flex-1"
                      >
                        <DollarSign className="h-4 w-4 mr-2" />
                        Add Money
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <Target className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">No Savings Goals Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first savings goal to start building wealth for your family
            </p>
            <Button onClick={() => setShowAddGoal(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Add Money Dialog */}
      <Dialog open={showAddMoney} onOpenChange={setShowAddMoney}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Money to Goal</DialogTitle>
            <DialogDescription>
              How much would you like to add to "{selectedGoal?.title}"?
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddMoney} className="space-y-4">
            <div className="space-y-2">
              <Label>Amount ($)</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="100.00"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                required
              />
            </div>
            
            {selectedGoal && (
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="text-sm">
                  <div className="flex justify-between mb-1">
                    <span>Current amount:</span>
                    <span>${selectedGoal.current?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span>After deposit:</span>
                    <span>${((selectedGoal.current || 0) + parseFloat(depositAmount || '0')).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span>Remaining to goal:</span>
                    <span>${Math.max(0, selectedGoal.target - (selectedGoal.current || 0) - parseFloat(depositAmount || '0')).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => setShowAddMoney(false)} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                Add Money
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Family Competition */}
      {userProfile?.children?.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Family Savings Challenge
            </CardTitle>
            <CardDescription>Who can save the most this month?</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold">
                    1
                  </div>
                  <div>
                    <div className="font-medium">You (Parent)</div>
                    <div className="text-sm text-muted-foreground">Saved $320 this month</div>
                  </div>
                </div>
                <div className="text-2xl">🏆</div>
              </div>
              
              {userProfile.children.map((child, index) => (
                <div key={child.id || index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-chart-1 rounded-full flex items-center justify-center text-primary-foreground font-bold">
                      {index + 2}
                    </div>
                    <div>
                      <div className="font-medium">{child.name}</div>
                      <div className="text-sm text-muted-foreground">Saved ${Math.floor(Math.random() * 50) + 10} this month</div>
                    </div>
                  </div>
                  <div className="text-xl">{index === 0 ? '🥈' : '🥉'}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}