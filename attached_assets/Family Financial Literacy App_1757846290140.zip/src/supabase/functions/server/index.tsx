import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Middleware
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))
app.use('*', logger(console.log))

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
)

// Health check
app.get('/make-server-ecad854b/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// User registration
app.post('/make-server-ecad854b/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json()

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log('Registration error:', error)
      return c.json({ error: error.message }, 400)
    }

    return c.json({ message: 'User created successfully', user: data.user })
  } catch (error) {
    console.log('Registration error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Create/Update user profile
app.post('/make-server-ecad854b/profile/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const profileData = await c.req.json()
    
    // Store profile data
    await kv.set(`user:${userId}:profile`, {
      id: userId,
      email: user.email,
      ...profileData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })

    // Initialize dashboard data
    await kv.set(`user:${userId}:dashboard`, {
      totalBalance: profileData.monthlyIncome * 0.1 || 1000, // Start with some sample balance
      monthlyIncome: profileData.monthlyIncome || 0,
      monthlyBudget: profileData.monthlyBudget || 0,
      budgetUsed: 0,
      savingsGoals: profileData.financialGoals?.map((goal, index) => ({
        id: index + 1,
        title: goal,
        target: goal.includes('Emergency') ? 10000 : 5000,
        current: Math.floor(Math.random() * 1000),
        category: 'Personal'
      })) || [],
      investments: [],
      children: profileData.children || []
    })

    const profile = await kv.get(`user:${userId}:profile`)
    return c.json(profile)
  } catch (error) {
    console.log('Profile creation error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Get user profile
app.get('/make-server-ecad854b/profile/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const profile = await kv.get(`user:${userId}:profile`)
    
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404)
    }

    return c.json(profile)
  } catch (error) {
    console.log('Profile fetch error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Get user dashboard data
app.get('/make-server-ecad854b/dashboard/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    
    if (!dashboardData) {
      // Initialize default dashboard data
      const defaultData = {
        totalBalance: 12459.50,
        monthlyBudget: 3500,
        budgetUsed: 2800,
        savingsGoals: [
          {
            id: 1,
            title: "Family Vacation",
            target: 5000,
            current: 3200,
            category: "Travel"
          }
        ],
        investments: [],
        children: [
          {
            id: 1,
            name: "Emma",
            age: 12,
            balance: 125.50,
            points: 450
          }
        ]
      }
      
      await kv.set(`user:${userId}:dashboard`, defaultData)
      return c.json(defaultData)
    }

    return c.json(dashboardData)
  } catch (error) {
    console.log('Dashboard fetch error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Create new savings goal
app.post('/make-server-ecad854b/savings-goal/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const goalData = await c.req.json()
    
    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (!dashboardData) {
      return c.json({ error: 'Dashboard not found' }, 404)
    }

    // Create new goal with unique ID
    const newGoal = {
      id: Date.now(),
      ...goalData,
      current: 0,
      created_at: new Date().toISOString()
    }

    dashboardData.savingsGoals = dashboardData.savingsGoals || []
    dashboardData.savingsGoals.push(newGoal)

    await kv.set(`user:${userId}:dashboard`, dashboardData)
    
    return c.json({ message: 'Savings goal created successfully', goal: newGoal })
  } catch (error) {
    console.log('Savings goal creation error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Update savings goal
app.put('/make-server-ecad854b/savings-goal/:userId/:goalId', async (c) => {
  try {
    const userId = c.req.param('userId')
    const goalId = c.req.param('goalId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { amount } = await c.req.json()
    
    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (!dashboardData) {
      return c.json({ error: 'Dashboard not found' }, 404)
    }

    // Update the specific savings goal
    dashboardData.savingsGoals = dashboardData.savingsGoals.map(goal => {
      if (goal.id === parseInt(goalId)) {
        return { ...goal, current: goal.current + amount }
      }
      return goal
    })

    await kv.set(`user:${userId}:dashboard`, dashboardData)
    
    return c.json({ message: 'Savings goal updated successfully' })
  } catch (error) {
    console.log('Savings goal update error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Delete savings goal
app.delete('/make-server-ecad854b/savings-goal/:userId/:goalId', async (c) => {
  try {
    const userId = c.req.param('userId')
    const goalId = c.req.param('goalId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (!dashboardData) {
      return c.json({ error: 'Dashboard not found' }, 404)
    }

    // Remove the specific savings goal
    dashboardData.savingsGoals = dashboardData.savingsGoals.filter(goal => 
      goal.id !== parseInt(goalId)
    )

    await kv.set(`user:${userId}:dashboard`, dashboardData)
    
    return c.json({ message: 'Savings goal deleted successfully' })
  } catch (error) {
    console.log('Savings goal deletion error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Add transaction
app.post('/make-server-ecad854b/transaction/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { amount, description, category, type } = await c.req.json()
    
    const transaction = {
      id: Date.now(),
      amount,
      description,
      category,
      type, // 'income' or 'expense'
      date: new Date().toISOString(),
      userId
    }

    // Store transaction
    const transactionKey = `user:${userId}:transaction:${transaction.id}`
    await kv.set(transactionKey, transaction)

    // Update dashboard balance
    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (dashboardData) {
      if (type === 'income') {
        dashboardData.totalBalance += amount
      } else {
        dashboardData.totalBalance -= amount
        dashboardData.budgetUsed += amount
      }
      await kv.set(`user:${userId}:dashboard`, dashboardData)
    }

    return c.json({ message: 'Transaction added successfully', transaction })
  } catch (error) {
    console.log('Transaction error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Get transactions
app.get('/make-server-ecad854b/transactions/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const transactions = await kv.getByPrefix(`user:${userId}:transaction:`)
    
    // Sort by date (newest first)
    const sortedTransactions = transactions.sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    )

    return c.json(sortedTransactions)
  } catch (error) {
    console.log('Transactions fetch error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Child account management
app.post('/make-server-ecad854b/child/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { name, age } = await c.req.json()
    
    const child = {
      id: Date.now(),
      name,
      age,
      balance: 0,
      points: 0,
      level: "Bronze Explorer",
      created_at: new Date().toISOString()
    }

    // Update dashboard with new child
    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (dashboardData) {
      dashboardData.children.push(child)
      await kv.set(`user:${userId}:dashboard`, dashboardData)
    }

    return c.json({ message: 'Child account created successfully', child })
  } catch (error) {
    console.log('Child account creation error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

// Update child balance
app.put('/make-server-ecad854b/child/:userId/:childId/balance', async (c) => {
  try {
    const userId = c.req.param('userId')
    const childId = c.req.param('childId')
    
    // Verify user authorization
    const accessToken = c.req.header('Authorization')?.split(' ')[1]
    const { data: { user }, error } = await supabase.auth.getUser(accessToken)
    
    if (!user || user.id !== userId) {
      return c.json({ error: 'Unauthorized' }, 401)
    }

    const { amount, type } = await c.req.json() // type: 'add' or 'subtract'
    
    const dashboardData = await kv.get(`user:${userId}:dashboard`)
    if (!dashboardData) {
      return c.json({ error: 'Dashboard not found' }, 404)
    }

    // Update child balance
    dashboardData.children = dashboardData.children.map(child => {
      if (child.id === parseInt(childId)) {
        const newBalance = type === 'add' ? child.balance + amount : child.balance - amount
        return { ...child, balance: Math.max(0, newBalance) }
      }
      return child
    })

    await kv.set(`user:${userId}:dashboard`, dashboardData)
    
    return c.json({ message: 'Child balance updated successfully' })
  } catch (error) {
    console.log('Child balance update error:', error)
    return c.json({ error: 'Internal server error' }, 500)
  }
})

Deno.serve(app.fetch)