import React, { useState, useEffect } from 'react';
import { Home, PiggyBank, Gamepad2, TrendingUp, Shield, User, Settings } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { SavingsGoals } from './components/SavingsGoals';
import { Games } from './components/Games';
import { Trading } from './components/Trading';
import { Protection } from './components/Protection';
import { FootstepsSection } from './components/FootstepsSection';
import { AuthScreen } from './components/AuthScreen';
import { OnboardingFlow } from './components/OnboardingFlow';
import { ProfileSetup } from './components/ProfileSetup';
import { createClient } from './utils/supabase/client';
import { Button } from './components/ui/button';
import { authenticatedRequest } from './utils/api';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showProfileSetup, setShowProfileSetup] = useState(false);
  const supabase = createClient();

  useEffect(() => {
    const initializeApp = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        setUser(session?.user || null);
        
        if (session?.user) {
          // Check if user has completed profile setup
          try {
            const profile = await authenticatedRequest(
              `/profile/${session.user.id}`,
              session.access_token
            );
            setUserProfile(profile);
            
            // If no profile exists, show profile setup
            if (!profile || !profile.setupComplete) {
              setShowProfileSetup(true);
            }
          } catch (error) {
            console.log('Profile not found, showing setup');
            setShowProfileSetup(true);
          }
        }
      } catch (error) {
        console.error('App initialization error:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeApp();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user || null);
        if (session?.user && event === 'SIGNED_IN') {
          setShowOnboarding(true);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setUserProfile(null);
    setShowOnboarding(false);
    setShowProfileSetup(false);
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    setShowProfileSetup(true);
  };

  const handleProfileSetupComplete = (profile) => {
    setUserProfile(profile);
    setShowProfileSetup(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading Aetherius...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  if (showOnboarding) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  if (showProfileSetup) {
    return <ProfileSetup onComplete={handleProfileSetupComplete} user={user} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-primary">Aetherius</h1>
              <p className="text-muted-foreground text-sm">
                {userProfile?.familyName || 'Your'} Family Finances
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm">{userProfile?.name || user.email}</p>
                <p className="text-xs text-muted-foreground">
                  {userProfile?.children?.length || 0} children connected
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowProfileSetup(true)}
                className="h-10 w-10 rounded-full p-0"
              >
                <Settings className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSignOut}
                className="h-10 w-10 rounded-full p-0"
              >
                <User className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6">
        {activeTab === 'home' && <Dashboard userProfile={userProfile} />}
        {activeTab === 'savings' && <SavingsGoals userProfile={userProfile} />}
        {activeTab === 'games' && <Games userProfile={userProfile} />}
        {activeTab === 'trading' && <Trading userProfile={userProfile} />}
        {activeTab === 'protection' && <Protection userProfile={userProfile} />}
      </div>

      {/* Footsteps Section */}
      {userProfile?.children?.length > 0 && (
        <FootstepsSection userProfile={userProfile} />
      )}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
        <div className="flex items-center justify-around py-2">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'savings', icon: PiggyBank, label: 'Savings' },
            { id: 'games', icon: Gamepad2, label: 'Games' },
            { id: 'trading', icon: TrendingUp, label: 'Trading' },
            { id: 'protection', icon: Shield, label: 'Protection' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center p-3 rounded-lg transition-colors ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span className="text-xs mt-1">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Add padding to prevent content overlap with bottom nav */}
      <div className="h-20"></div>
    </div>
  );
}